# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import zipfile, xbmcaddon, xbmc, uservar, sys, os, time,logging
import wizard as wiz,sys

ADDON_ID       = uservar.ADDON_ID
ADDONTITLE     = uservar.ADDONTITLE
COLOR1         = uservar.COLOR1
COLOR2         = uservar.COLOR2
ADDON          = wiz.addonId(ADDON_ID)
HOME           = xbmc.translatePath('special://home/')
USERDATA       = os.path.join(HOME,      'userdata')
GUISETTINGS    = os.path.join(USERDATA,  'guisettings.xml')
KEEPMOVIEWALL    = wiz.getS('keepmoviewall')
KEEPMOVIELIST    = wiz.getS('keepmovielist')
KEEPINFO         = wiz.getS('keepinfo')
KEEPSOUND        = wiz.getS('keepsound')
KEEPTORNET       = wiz.getS('keeptornet')
KEEPREAL         = wiz.getS('keepdebrid')
KEEPVIEW         = wiz.getS('keepview')
KEEPPLAYLIST     = wiz.getS('keepplaylist')
KEEPSKIN         = wiz.getS('keepskin')
KEEPSKIN2        = wiz.getS('keepskin2')
KEEPSKIN3        = wiz.getS('keepskin3')
KEEPPVR          = wiz.getS('keeppvr')
KEEPFAVS       = wiz.getS('keepfavourites')
KEEPSOURCES    = wiz.getS('keepsources')
KEEPPROFILES   = wiz.getS('keepprofiles')
KEEPADVANCED   = wiz.getS('keepadvanced')
KEEPSUPER      = wiz.getS('keepsuper')
KEEPREPOS      = wiz.getS('keeprepos')
KEEPWHITELIST  = wiz.getS('keepwhitelist')
KODIV          = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
LOGFILES       = ['xbmc.log', 'xbmc.old.log', 'kodi.log', 'kodi.old.log', 'spmc.log', 'spmc.old.log', 'tvmc.log', 'tvmc.old.log', 'Thumbs.db', '.gitignore', '.DS_Store']
bad_files      = ['onechannelcache.db', 'saltscache.db', 'saltscache.db-shm', 'saltscache.db-wal', 'saltshd.lite.db', 'saltshd.lite.db-shm', 'saltshd.lite.db-wal', 'queue.db', 'commoncache.db', 'access.log', 'trakt.db', 'video_cache.db']

def all(_in, _out, dp=None, ignore=None, title=None,keep_userdata=False):
	if dp: return allWithProgress(_in, _out, dp, ignore, title,keep_userdata)
	else: return allNoProgress(_in, _out, ignore)

def allNoProgress(_in, _out, ignore):
	try:
		zin = zipfile.ZipFile(_in, 'r')
		zin.extractall(_out)
	except Exception, e:
		print str(e)
		return False
	return True

def allWithProgress(_in, _out, dp, ignore, title,keep_userdata):
	reload(sys)
	sys.setdefaultencoding("utf-8")
	count = 0; errors = 0; error = ''; update = 0; size = 0; excludes = []
	try:
		zin = zipfile.ZipFile(_in,  'r')
	except Exception, e:
		errors += 1; error += '%s\n' % e
		wiz.log('Error Checking Zip: %s' % str(e), xbmc.LOGERROR)
		return update, errors, error
	
	whitelist = wiz.whiteList('read')
	for item in whitelist:
		try: name, id, fold = item
		except: pass
		excludes.append(fold)
		if fold.startswith('pvr'):
			wiz.setS('pvrclient', id)
	
	nFiles = float(len(zin.namelist()))
	zipsize = wiz.convertSize(sum([item.file_size for item in zin.infolist()]))

	zipit = str(_in).replace('\\', '/').split('/')
	title = title if not title == None else zipit[-1].replace('.zip', '')

	for item in zin.infolist():
		count += 1; prog = int(count / nFiles * 100); size += item.file_size
		logging.warning(item.filename)
		file = (item.filename).split('/')
		skip = False
		line1  = '%s [COLOR %s][B][Errors:%s][/B][/COLOR]' % (title, COLOR2, errors)
		line2  = '[COLOR %s][B]File:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR] ' % (COLOR2, COLOR1, count, int(nFiles))
		line2 += '[COLOR %s][B]Size:[/B][/COLOR] [COLOR %s]%s/%s[/COLOR]' % (COLOR2, COLOR1, wiz.convertSize(size), zipsize)
		line3  = '[COLOR %s]%s[/COLOR]' % (COLOR1, item.filename)

		if item.filename == 'userdata/sources.xml' and KEEPSOURCES == 'true': skip = True
		elif 'script.skinshortcuts' in item.filename and 'userdata' in item.filename and KEEPSKIN =='true':skip=True
		elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIEWALL =='false':skip=True
		elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIEWALL =='false':skip=True
		elif item.filename == 'userdata/Database/MyVideos109.db' and KEEPMOVIEWALL =='false':skip=True
		elif item.filename == 'userdata/Database/MyVideos99.db' and KEEPMOVIELIST =='true':skip=True
		elif item.filename == 'userdata/Database/MyVideos107.db' and KEEPMOVIELIST =='true':skip=True
		elif item.filename == 'userdata/Database/MyVideos109.db' and KEEPMOVIELIST =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.anonymous.mod' and KEEPVIEW =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPVIEW =='true':skip=True
		elif 'pvr.iptvsimple' in item.filename and 'userdata' in item.filename and KEEPPVR =='true':skip=True
		elif file[0] == 'userdata' and keep_userdata==True:skip=True
		elif file[1] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.anonymous.wall' and KEEPMOVIEWALL =='false':skip=True
		#elif file[1] == 'skin.phenomenal' and KEEPSKIN2 =='false':skip=True	
		elif file[1] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True	
		elif file[1] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True	
		elif file[1] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
		#elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.phenomenal' and KEEPSKIN2 =='false':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod.Krypton' and KEEPSKIN2 =='false':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.eminence.2.mod' and KEEPSKIN2 =='false':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'skin.titan' and KEEPSKIN3 =='false':skip=True
		elif item.filename == 'userdata/favourites.xml' and KEEPFAVS == 'true': skip = True
		elif item.filename == 'userdata/guisettings.xml' and KEEPSOUND == 'true': skip = True
		elif item.filename == 'userdata/profiles.xml' and KEEPPROFILES == 'true': skip = True
		elif item.filename == 'userdata/advancedsettings.xml' and KEEPADVANCED == 'true': skip = True
		elif file[0] == 'addons' and file[1] in excludes: skip = True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] in excludes: skip = True
		elif file[-1] in LOGFILES: skip = True
		elif file[-1] in bad_files: skip = True
		elif file[-1].endswith('.csv'): skip = True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.sdarot.tv' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'program.apollo' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.gaia' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.elementum' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.boxsetkings' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.bennu' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.ebs_movixws' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.elysium' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.allmoviesin' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.thewiz' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.neptune' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.youtube' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.subscenter' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.opensubtitles' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.All_Subs' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'service.subtitles.wizdom' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.IPTVIP' and KEEPTORNET =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.triton' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.incursion' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.bob.unleashed' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.audio.soundcloud' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.kodipopcorntime' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.torrenter' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.quasar' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.PastebinPlay' and KEEPINFO =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'plugin.video.playlistLoader' and KEEPPLAYLIST =='true':skip=True
		elif file[0] == 'userdata' and file[1] == 'addon_data' and file[2] == 'script.module.resolveurl' and KEEPREAL =='true':skip=True
		elif not (item.filename).find('plugin.program.super.favourites') == -1 and KEEPSUPER == 'true': skip = True

		elif not (item.filename).find(ADDON_ID)                          == -1 and ignore == None: skip = True
		if skip == True: wiz.log("Skipping: %s" % item.filename, xbmc.LOGNOTICE)
		else:
			try:
				zin.extract(item, _out)
			except Exception, e:
				errormsg  = "[COLOR %s]File:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, file[-1])
				errormsg += "[COLOR %s]Folder:[/COLOR] [COLOR %s]%s[/COLOR]\n" % (COLOR2, COLOR1, (item.filename).replace(file[-1],''))
				errormsg += "[COLOR %s]Error:[/COLOR] [COLOR %s]%s[/COLOR]\n\n" % (COLOR2, COLOR1, str(e).replace('\\\\','\\').replace("'%s'" % item.filename, ''))
				errormsg += ('Error on line {}'.format(sys.exc_info()[-1].tb_lineno))
				errors += 1; error += errormsg
				wiz.log('Error Extracting: %s(%s)' % (item.filename, str(e)), xbmc.LOGERROR)
				pass
		dp.update(prog, line1, line2, line3)
		if dp.iscanceled(): break
	if dp.iscanceled(): 
		dp.close()
		wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Extract Cancelled[/COLOR]" % COLOR2)
		sys.exit()
	return prog, errors, error